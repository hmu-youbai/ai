import Levenshtein as L
import numpy as np
def DNA_complement1(sequence):
    comp_dict = {
        "A":"T",
        "T":"A",
        "G":"C",
        "C":"G",
        "a":"t",
        "t":"a",
        "g":"c",
        "c":"g",
        "u":"a",
        "N":"N"
    }
    sequence_list = list(sequence)
    sequence_list = [comp_dict[base] for base in sequence_list]
    sequence_list.reverse()
    string = ''.join(sequence_list)
    return string
def yichucuowu(aaa,bbb):
    bbbindex = np.nonzero(np.array(np.fromstring(aaa, dtype=np.uint8) ^ np.fromstring(bbb, dtype=np.uint8)))[0]
    if len(bbbindex)>1:
        dd = bbb[:bbbindex[1]]
    else:
        dd=bbb
    return dd
def check(str1, str2):
    length1 = len(str1)
    length = min(length1, len(str2))
    k = max(range(0, length + 1),
            key=lambda i: i if L.hamming(str1[length1-i:], str2[:i])<2  else False)
    return str2[:k],k
def check0(str1, str2):
    length1 = len(str1)
    length = min(length1, len(str2))
    k = max(range(0, length + 1),
            key=lambda i: i if L.hamming(str1[length1-i:], str2[:i])<1  else False)
    return str2[:k],k
def check1(str1, str2):
    length1 = len(str1)
    length = min(length1, len(str2))
    k = max(range(0, length + 1),
            key=lambda i: i if L.hamming(str1[length1-i:], str2[:i])<2  else False)
    return str2[:k],k
def check2(str1, str2):
    length1 = len(str1)
    length = min(length1, len(str2))
    k = max(range(0, length + 1),
            key=lambda i: i if L.hamming(str1[length1-i:], str2[:i])<3  else False)
    return str2[:k],k

def overfile(filer1,filer2):
    with open(filer1)as file1,open(filer2)as file2,open("over_huanyuan.fa","w")as file3:
        cc=0
        c1=[]
        c2=[]
        for line in file1:
            line=line.strip()
            cc=cc+1
            if cc% 4==2:
                c1.append(line)
        cc=0
        for line in file2:
            line = line.strip()
            cc=cc+1
            if cc % 4 == 2:
                c2.append(line)

        for i in range(len(c1)):
            nn = check2(c1[i], DNA_complement1(c2[i]))[1]
            new = c1[i] + DNA_complement1(c2[i])[nn:]
            print(">name" + str(i), file=file3)
            print(new, file=file3)






