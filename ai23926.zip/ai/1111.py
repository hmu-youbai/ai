import os
import sys
import Levenshtein as L
import numpy as np
def DNA_complement1(sequence):
    comp_dict = {
        "A":"T",
        "T":"A",
        "G":"C",
        "C":"G",
        "a":"t",
        "t":"a",
        "g":"c",
        "c":"g",
        "u":"a",
        "N":"N"
    }
    sequence_list = list(sequence)
    sequence_list = [comp_dict[base] for base in sequence_list]
    sequence_list.reverse()
    string = ''.join(sequence_list)
    return string
def yichucuowu(aaa,bbb):
    bbbindex = np.nonzero(np.array(np.fromstring(aaa, dtype=np.uint8) ^ np.fromstring(bbb, dtype=np.uint8)))[0]
    if len(bbbindex)>1:
        dd = bbb[:bbbindex[1]]
    else:
        dd=bbb
    return dd
def check(str1, str2):
    length = min(len(str1), len(str2))
    k = max(range(0, length + 1),
            key=lambda i: i if L.hamming(str1[len(str1)-i:], str2[:i])<2  else False)
    return str2[:k],k



gg=0
with open("qiehaowuover", "r") as file, open("wu1222", "w") as file1:
    for line in file:
        line = line.strip()
        line = line.split()
        se333 = line[0]
        se111 = line[1]
        se222 = line[2]
        m = min(len(se111), len(se222))
        r111 = se111[:m]
        r222 = se222[:m]
        r111 = r111.replace("C", "T")
        r222 = r222.replace("C", "T")
        sss = yichucuowu(r111, r222)
        sss=len(sss)
        gg=gg+sss
        if sss>35:
            print(">" + se333, file=file1)
            print(se222[:sss], file=file1)


def zhijieqie(qiehaowuover):
    gg = 0
    with open(qiehaowuover, "r") as file, open("zjqie.fa", "w") as file1:
        for line in file:
            line = line.strip()
            line = line.split()
            se333 = line[0]
            se111 = line[1]
            se222 = line[2]
            m = min(len(se111), len(se222))
            r111 = se111[:m]
            r222 = se222[:m]
            r111 = r111.replace("C", "T")
            r222 = r222.replace("C", "T")
            sss = yichucuowu(r111, r222)
            sss = len(sss)
            gg = gg + sss
            if sss > 35:
                print(">" + se333, file=file1)
                print(se222[:sss], file=file1)