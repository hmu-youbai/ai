确保python3.9及以上已安装，并且添加到环境变量
python通常的安装位置：C:\Users\用户名\AppData\Local\Programs\Python
########################
安装完成后，双击main.pyw运行