def DNA_complement1(sequence):
    comp_dict = {
        "A":"T",
        "T":"A",
        "G":"C",
        "C":"G",
        "a":"t",
        "t":"a",
        "g":"c",
        "c":"g",
        "u":"a",
        "N":"N"
    }
    sequence_list = list(sequence)
    sequence_list = [comp_dict[base] for base in sequence_list]
    # sequence_list.reverse()
    string = ''.join(sequence_list)
    return string


a1="CTTTAATCATAAAGTCCAGAATCTGGAAACAACCTAGATGACCCTCAACAGATGAATGGATAAAGGAAGTGTGCTACATTTACACAATGGAGTATTACTCAGCTATTAAAAGCAATGACATCATGAAATTTGCAGGCAAATGGATGAAAC"
print(DNA_complement1(a1))