




with open("qiehaowuover", "r") as file, open("qingxi1", "w") as file1:
    for line in file:
        line = line.strip()
        line = line.split()
        se333 = line[0]
        se111 = line[1]
        se222 = line[2]
        if len(se111) < 100 or len(se222) < 100:
            continue
        print(se333 + " " + se111 + " " + se222, file=file1)