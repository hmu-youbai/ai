import re


def extract_value(text, pattern):
    result = re.search(pattern, text)
    if result:
        return result.group(1)
    else:
        return None



raw_reads = extract_value("read before deduplication: 16613275  ", r'read before deduplication:\s*(\d+)')