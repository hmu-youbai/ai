def DNA_complement1(sequence):
    # 构建互补字典
    comp_dict = {
        "A":"T",
        "T":"A",
        "G":"C",
        "C":"G",
        "a":"t",
        "t":"a",
        "g":"c",
        "c":"g",
        "u":"a",
        "N":"N"

    }
    #求互补序列
    sequence_list = list(sequence)
    sequence_list = [comp_dict[base] for base in sequence_list]
    # s1 = sequence_list
    # s1 = ''.join(sequence_list)
    sequence_list.reverse()
    string = ''.join(sequence_list)
    return string
    # return s1
def quchongfa(r1name,r2name):
    num = 0
    r1 = []
    with open(r1name, 'r') as file1:
        for line in file1:
            num = num + 1
            if (num % 4) == 2:
                r1.append(line.strip())
    file1.close()
    num = 0
    r2 = []
    with open(r2name, 'r') as file2:
        for line in file2:
            num = num + 1
            if (num % 4) == 2:
                r2.append(line.strip())
    file2.close()

    cc1 = []
    for i in range(len(r1)):
        cc1.append(r1[i] + " " + r2[i])
    cc2 = list(set(cc1))

    jieguo="r1r2set"
    with open(jieguo, 'w') as file3:
        for i in range(len(cc2)):
            print("name" + str(i) + " " + cc2[i].split()[0] + " " + cc2[i].split()[1], file=file3)
    file3.close()

    out_file = "r1.fa"
    fin = open(jieguo, 'r')
    fout = open(out_file, 'w')
    i = 0
    for line in fin:
        line = line.strip()
        eles = line.split()
        r1_seq = eles[0]
        r2_seq = eles[1]
        print('%s%d%s%s' % (">", i, "_", r1_seq), file=fout)
        print('%s' % (r2_seq), file=fout)
        i += 1
    fin.close()
    fout.close()

    out_file = "r2.fa"
    fin = open(jieguo, 'r')
    fout = open(out_file, 'w')
    i = 0
    for line in fin:
        line = line.strip()
        eles = line.split()
        r1_seq = eles[0]
        r2_seq = eles[2]
        print('%s%d%s%s' % (">", i, "_", r1_seq), file=fout)
        print('%s' % (r2_seq), file=fout)
        i += 1
    fin.close()
    fout.close()


def quchongr1(r1name):
    num = 0
    r1 = []
    with open(r1name, 'r') as file1:
        for line in file1:
            num = num + 1
            if (num % 4) == 2:
                r1.append(line.strip())
    file1.close()
    return r1
def quchongr2(r2name):
    num = 0
    r2 = []
    with open(r2name, 'r') as file2:
        for line in file2:
            num = num + 1
            if (num % 4) == 2:
                r2.append(line.strip())
    file2.close()
    return r2
def quchongset(r1,r2):
    cc1 = []
    for i in range(len(r1)):
        cc1.append(r1[i] + " " + r2[i])
    cc2 = list(set(cc1))
    jieguo="r1r2set"
    with open(jieguo, 'w') as file3:
        for i in range(len(cc2)):
            print("name" + str(i) + " " + cc2[i].split()[0] + " " + cc2[i].split()[1], file=file3)
    file3.close()
    return len(cc2)

def quchongw1():
    out_file = "r1.fa"
    fin = open("r1r2set", 'r')
    fout = open(out_file, 'w')
    i = 0
    for line in fin:
        line = line.strip()
        eles = line.split()
        r1_seq = eles[0]
        r2_seq = eles[1]
        print('%s%d%s%s' % (">", i, "_", r1_seq), file=fout)
        print('%s' % (r2_seq), file=fout)
        i += 1
    fin.close()
    fout.close()

def quchongw2():
    out_file = "r2.fa"
    fin = open("r1r2set", 'r')
    fout = open(out_file, 'w')
    i = 0
    for line in fin:
        line = line.strip()
        eles = line.split()
        r1_seq = eles[0]
        r2_seq = eles[2]
        print('%s%d%s%s' % (">", i, "_", r1_seq), file=fout)
        print('%s' % (r2_seq), file=fout)
        i += 1
    fin.close()
    fout.close()



def readgenome(name):
    seq_file = []
    i = 0
    cc = []
    with open(name, 'r') as input_fasta:
        for line in input_fasta:
            line = line.strip()
            if line[0] == '>':
                print(line)
                cc.append(i)
            seq_file.append(line)
            i = i + 1
    input_fasta.close()

    dd = {}
    for i in range(len(cc) - 1):
        ss = "".join(seq_file[cc[i] + 1:cc[i + 1]])
        pp = seq_file[cc[i]].split()
        pp = pp[0]
        # print(pp)
        dd[pp] = ss
    ss = "".join(seq_file[(cc[len(cc) - 1] + 1):(len(seq_file) - 1)])
    print(seq_file[cc[len(cc) - 1]].split()[0])
    dd[seq_file[cc[len(cc) - 1]].split()[0]] = ss
    return dd


def writegps_sam(samname, dd, cutr1):
    bt = []
    cc = []
    with open(samname, 'r') as f1018:  #############这里是sam
        for line in f1018:
            line = line.strip()
            line2 = line.split()
            if line2[0].startswith('@'):
                bt.append(line)
                continue
            if str(line2[1]) == "4":
                continue
            if len(line2[5]) > 4:
                continue

            if int(line2[1]) == 0:
                if int(line2[3]) - 1 - 2 < 0:
                    continue
                if int(line2[3]) - 1 + len(line2[9]) + 2 > len(dd[">" + line2[2]]):
                    continue
                ref = dd[">" + line2[2]][int(line2[3]) - 1:int(line2[3]) - 1 + len(line2[9]) + 2]  ###   len(line2[9])
                # if len(ref) < 1000:
                #     ref = dd[">" + line2[2]][int(line2[3]) - 1:]
            else:
                if int(line2[3]) - 1 + len(line2[9]) + 2 > len(dd[">" + line2[2]]):
                    continue
                if int(line2[3]) - 1 - 2 < 0:
                    continue
                ref = dd[">" + line2[2]][int(line2[3]) - 1 - 2:int(line2[3]) + len(line2[9]) - 1]
                # if len(ref)< 1000:
                #     ref = dd[">" + line2[2]][:int(line2[3]) + len(line2[9]) - 1]
                # ref = DNA_complement1(ref)

            tt = line2[0] + " " + line2[1] + " " + line2[2] + " " + line2[3] + " " + ref
            cc.append(tt)

    f1018.close()
    refff = cc
    rrref = {}
    for line in refff:
        line = line.split()
        rrref[line[0]] = line[1] + " " + line[2] + " " + line[3] + " " + line[4]
    rrr2 = {}
    j = 0
    with open(cutr1, "r") as file1:
        for line in file1:
            line = line.strip()
            j = j + 1
            if j % 2 == 1:
                c1 = line[1:]
            else:
                c2 = line
                rrr2[c1] = c2
    file1.close()
    kkk = [x for x in rrref.keys()]
    ############   MD
    MD = []
    for i in rrref.keys():
        a1 = rrref[i].split(" ")
        b1 = rrr2[i]  ########yuan
        b2 = a1[3]  ############### ref
        if str(a1[0]) == "0":
            js = 0
            ws = ""
            for j in range(len(b1)):
                if b1[j] == b2[j]:
                    js = js + 1
                else:
                    ws = ws + str(js) + b2[j]
                    js = 0
            ws = ws + str(js)
        if str(a1[0]) == "16":
            b1 = DNA_complement1(b1)
            js = 0
            ws = ""
            for j in range(len(b1)):
                if b1[j] == b2[j + 2]:
                    js = js + 1
                else:
                    ws = ws + str(js) + b2[j + 2]
                    js = 0
            ws = ws + str(js)
        MD.append(ws)

    ############   NM
    NM = []
    for i in MD:
        b = 0
        for j in i:
            if j.isupper():
                b = b + 1
        NM.append(b)
    ############   XM
    XM = []
    for i in rrref.keys():
        a1 = rrref[i].split(" ")
        b1 = rrr2[i]  ########yuan
        b2 = a1[3]  ############### ref
        if str(a1[0]) == "0":
            ws = ""
            for j in range(len(b1)):
                if b2[j] == "C" and b1[j] == "C":
                    if b2[j + 1] == "G":
                        ws = ws + "Z"
                    elif b2[j + 2] == "G":
                        ws = ws + "X"
                    else:
                        ws = ws + "H"
                elif b2[j] == "C" and b1[j] == "T":
                    if b2[j + 1] == "G":
                        ws = ws + "z"
                    elif b2[j + 2] == "G":
                        ws = ws + "x"
                    else:
                        ws = ws + "h"
                else:
                    ws = ws + "."
        if str(a1[0]) == "16":
            b1 = DNA_complement1(b1)
            ws = ""
            for j in range(len(b1)):
                if b2[j + 2] == "G" and b1[j] == "G":
                    if b2[j + 1] == "C":
                        ws = ws + "Z"
                    elif b2[j] == "C":
                        ws = ws + "X"
                    else:
                        ws = ws + "H"
                elif b2[j + 2] == "G" and b1[j] == "A":
                    if b2[j + 1] == "C":
                        ws = ws + "z"
                    elif b2[j] == "C":
                        ws = ws + "x"
                    else:
                        ws = ws + "h"
                else:
                    ws = ws + "."
        XM.append(ws)

    ###################XR:Z:CT	XG:Z:CT
    ###################XR:Z:CT	XG:Z:GA

    XRXG = []
    for i in rrref.keys():
        a1 = rrref[i].split(" ")
        b1 = rrr2[i]  ########yuan
        b2 = a1[3]  ############### ref
        if str(a1[0]) == "0":
            XRXG.append("XR:Z:CT	XG:Z:CT")
        if str(a1[0]) == "16":
            XRXG.append("XR:Z:CT	XG:Z:GA")

    ########################
    jieguo = []
    for i in range(len(kkk)):
        a1 = rrref[kkk[i]].split()
        b1 = rrr2[kkk[i]]  ########yuan
        b2 = a1[3]  ############### ref
        if str(a1[0]) == "0":
            ws = kkk[i] + "	" + a1[0] + "	" + a1[1] + "	" + a1[2] + "	" + "42" + "	" + str(
                len(b1)) + "M" + "	*	0	0	" + b1 + "	" + "I" * len(b1) + "	" + "NM:i:" + str(
                NM[i]) + "	" + "MD:Z:" + str(MD[i]) + "	" + "XM:Z:" + str(XM[i]) + "	" + XRXG[i]
        if str(a1[0]) == "16":
            ws = kkk[i] + "	" + a1[0] + "	" + a1[1] + "	" + a1[2] + "	" + "42" + "	" + str(
                len(b1)) + "M" + "	*	0	0	" + DNA_complement1(b1) + "	" + "I" * len(
                b1) + "	" + "NM:i:" + str(NM[i]) + "	" + "MD:Z:" + str(MD[i]) + "	" + "XM:Z:" + str(
                XM[i]) + "	" + XRXG[i]
        jieguo.append(ws)

    for i in jieguo:
        bt.append(i)
    with open("gps.sam", "w") as file1:
        for i in bt:
            print(i, file=file1)
    file1.close()

