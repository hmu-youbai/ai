import wx


class Ui_tran1_2:
    def setupUi(self, tran1_2):
        tran1_2.SetTitle("Form")
        tran1_2.SetSize((629, 373))
        self.findfile = wx.Button(tran1_2, label="Find File", pos=(130, 100), size=(131, 51))
        self.uploadfile = wx.Button(tran1_2, label="Log File", pos=(360, 100), size=(131, 51))

    def retranslateUi(self, tran1_2):
        pass