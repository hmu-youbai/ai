import argparse
from collections import defaultdict





def get_and_remain(interval, my_list):
    start=interval[0]
    end=interval[1]
    remain_list=[]
    result_list=[]

    for i,temp in enumerate(my_list):
        if temp[1]<start:
            remain_list.append(temp)
        elif temp[0]>end:
            remain_list.extend(my_list[i:])
            break
        elif temp[0]<start and temp[1]>end:
            remain_list.append((temp[0],start-1))
            remain_list.append((end+1,temp[1]))
            result_list.append((start,end))
        elif temp[0]>=start and temp[1]<=end:
            result_list.append(temp)

        elif temp[0]<start and temp[1]<=end:
            remain_list.append((temp[0],start-1))
            result_list.append((start,temp[1]))
        elif temp[0]>=start and temp[1]>end:
            remain_list.append((end+1,temp[1]))
            result_list.append((temp[(0)],end))

    return result_list, remain_list
def get_new_dir(intervals_dir,key_list):
    all_intervals = [interval for intervals in intervals_dir.values() for interval in intervals]
    min_value = min(min(interval) for interval in all_intervals)
    max_value = max(max(interval) for interval in all_intervals)
    remain_A=[(min_value,max_value)]
    interval_dir2=defaultdict(list)
    for _ in key_list:
        temp_value=intervals_dir[_].copy()
        for val in temp_value:
            get_val,new_re=get_and_remain(val,remain_A)
            interval_dir2[_].extend(get_val)
            remain_A=new_re
    return interval_dir2









if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Description of your program')

    # 添加参数
    parser.add_argument('anno_file', type=str, help='Description of bed_file')

    parser.add_argument('chr', type=int, help='Description of dd')
    parser.add_argument('start', type=int, help='Description of dd')
    parser.add_argument('end', type=int, help='Description of dd')
    parser.add_argument('anno', type=int, help='Description of dd')
    parser.add_argument('priority_list', type=str, help='Description of dd')

    args = parser.parse_args()

    key_list = args.priority_list.split(',')



    all_intervals_dict=defaultdict(list)
    with open(args.anno_file,"w")as file,open(args.anno_file+"_remove_sect","w")as file2:
        for line in file:
            line=line.strip()
            if line.startswith("#"):
                continue
            line=line.split()
            all_intervals_dict[args.chr].append((line[args.start-1],line[args.end-1],args.anno))

        for chr,value in all_intervals_dict.items():
            intervals_dict = defaultdict(list)
            for _ in value:
                intervals_dict[_[2]].append((_[0],_[1]))

            my_dir = get_new_dir(intervals_dict, key_list)


            for my_key,my_value in my_dir.items():
                for temp in my_value:
                    print(chr+"\t"+str(temp[0])+"\t"+str(temp[1]+"\t"+my_key),file=file2)












