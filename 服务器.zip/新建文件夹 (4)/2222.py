from Bio import SeqIO


def readgenome(name):
    dd = {}
    with open(name, 'r') as input_fasta:
        for record in SeqIO.parse(input_fasta, 'fasta'):
            dd[record.id] = str(record.seq)
    return dd


dd = readgenome("/data/wangzc/cgs/new_mm9_lam_mc.fa")

bed_file = "my.sort.bedgraph"





with open(bed_file) as file:
    temp = 0
    zuo1 = 0
    zuo0 = 0
    for line in file:
        temp = temp + 1
        line = line.strip()
        line = line.split("\t")

        if temp <= 100000:
            if dd[line[0]][int(line[1]) - 1] in ["C", "G", "g", "c"]:
                zuo1 = zuo1 + 1
        elif temp > 100000:
            if dd[line[0]][int(line[1])] in ["C", "G", "g", "c"]:
                zuo0 = zuo0 + 1

        if temp == 200000:
            break

if zuo1 == 100000 and zuo0 != 100000:
    print("bed文件start对应位点，最小值从1开始，这是最一般的情况")
    with open(bed_file) as file, open(bed_file + ".strand", "w") as file2:
        for line in file:
            line = line.strip()
            raw_line = line
            line = line.split("\t")
            if dd[line[0]][int(line[1]) - 1] in ["C", "c"]:
                print(raw_line + "\t" + "+", file=file2)
            if dd[line[0]][int(line[1]) - 1] in ["G", "g"]:
                print(raw_line + "\t" + "-", file=file2)



elif zuo0 == 100000 and zuo1 != 100000:
    print("bed文件start对应位点，最小值从0开始，这是少见的情况")
    with open(bed_file) as file, open(bed_file + ".strand", "w") as file2:
        for line in file:
            line = line.strip()
            raw_line = line
            line = line.split("\t")
            if dd[line[0]][int(line[1])] in ["C", "c"]:
                print(raw_line + "\t" + "+", file=file2)
            if dd[line[0]][int(line[1])] in ["G", "g"]:
                print(raw_line + "\t" + "-", file=file2)
elif zuo0 != 100000 and zuo1 != 100000:
    print("参考基因组错误")
elif zuo0 == 100000 and zuo1 == 100000:
    print("错误，参考基因组正确，但是起点模式待定，不排除全正链的可能")
else:
    print("错误，啊？亚托克斯音效！")


