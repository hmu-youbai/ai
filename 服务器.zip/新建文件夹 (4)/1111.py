import argparse
import os

from Bio import SeqIO


def readgenome(name):
    dd = {}
    with open(name, 'r') as input_fasta:
        for record in SeqIO.parse(input_fasta, 'fasta'):
            dd[record.id] = str(record.seq)
    return dd



def determine_separator(line):
    if ' ' in line:
        separator = ' '
    elif '\t' in line:
        separator = '\t'
    else:
        separator = None

    return separator








def get_list(bed_file):
    list_for_yz=[]
    with open(bed_file) as file:
        temp = 0
        for line in file:
            if line.startswith("#"):
                continue
            temp = temp + 1
            list_for_yz.append(line.strip())
            if temp==200000:
                break

    if len(list_for_yz) != 200000:
        new_len = len(list_for_yz) - (len(list_for_yz) % 2)
    else:
        new_len = len(list_for_yz)

    return list_for_yz[:new_len], new_len





def start_yz(bed_file,dd,list_for_yz,new_len,num_chr,num_start):


    zuo1 = 0
    zuo0 = 0
    for i,line in enumerate(list_for_yz):
        line=line.split()
        if i < int(new_len/2):
            if dd[line[num_chr-1]][int(line[num_start-1]) - 1] in ["C", "G", "g", "c"]:
                zuo1 = zuo1 + 1
        elif i >= int(new_len/2):
            if dd[line[num_chr-1]][int(line[num_start-1])] in ["C", "G", "g", "c"]:
                zuo0 = zuo0 + 1



    if zuo1 == int(new_len/2) and zuo0 != int(new_len/2):
        print("参考基因组正确，bed文件start对应位点，start最小值从1开始，这是少见的情况，已纠正")
        if os.path.dirname(bed_file)=="":
            w_file="temp_" + bed_file
        else:
            w_file=os.path.dirname(bed_file)+"/temp_"+os.path.basename(bed_file)


        with open(bed_file) as file, open(w_file+"_z", "w") as file2,open(w_file+"_f", "w") as file3:
            for line in file:
                if line.startswith("#"):
                    continue
                line = line.strip()
                line = line.split()
                new_line = ' '.join(str(int(val) - 1) if idx == num_start - 1 else str(val) for idx, val in enumerate(line))

                if dd[line[0]][int(line[num_start - 1]) - 1] in ["C", "c"]:
                    print(new_line,file=file2)
                if dd[line[0]][int(line[num_start - 1]) - 1] in ["G", "g"]:
                    print(new_line,file=file3)

    elif zuo0 == int(new_len/2) and zuo1 != int(new_len/2):
        print("参考基因组正确，bed文件start对应位点，start最小值从0开始，这是最常见的情况")
        if os.path.dirname(bed_file)=="":
            w_file="temp_" + bed_file
        else:
            w_file=os.path.dirname(bed_file)+"/temp_"+os.path.basename(bed_file)

        with open(bed_file) as file, open(w_file+"_z", "w") as file2,open(w_file+"_f", "w") as file3:
            for line in file:
                line = line.strip()

                if dd[line[0]][int(line[num_start - 1]) - 1] in ["C", "c"]:
                    print(line,file=file2)
                if dd[line[0]][int(line[num_start - 1]) - 1] in ["G", "g"]:
                    print(line,file=file3)


    elif zuo0 != int(new_len/2) and zuo1 != int(new_len/2):
        print("参考基因组错误")
    elif zuo0 == int(new_len/2) and zuo1 == int(new_len/2):
        print("错误，参考基因组正确，但是起点模式待定，不排除全正链的可能")
    else:
        print("错误，啊？亚托克斯音效！")







if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Description of your program')

    # 添加参数
    parser.add_argument('bed_file', type=str, help='Description of bed_file')
    parser.add_argument('ref', type=str, help='Description of dd')


    parser.add_argument('num_chr', type=int, help='Description of num_chr')
    parser.add_argument('num_start', type=int, help='Description of num_start')

    # 解析命令行参数
    args = parser.parse_args()


    dd = readgenome(args.ref)
    list_for_yz,new_len=get_list(args.bed_file)

    start_yz(args.bed_file, dd, list_for_yz, new_len, args.num_chr, args.num_start)

