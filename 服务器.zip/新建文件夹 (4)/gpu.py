import numpy as np
import cupy as cp
import time

# 创建两个随机的 10000x10000 矩阵
matrix_size = 100000000
matrix_a = np.random.randint(0, 101, size=(matrix_size), dtype=int)
matrix_b = np.random.randint(0, 101, size=(matrix_size), dtype=int)

# 使用CPU计算矩阵加法
start_time_cpu = time.time()
result_cpu = matrix_a + matrix_b
end_time_cpu = time.time()
cpu_time = end_time_cpu - start_time_cpu

# 使用GPU（CUDA）计算矩阵加法
matrix_a_gpu = cp.asarray(matrix_a)
matrix_b_gpu = cp.asarray(matrix_b)

start_time_gpu = time.time()
result_gpu = matrix_a_gpu + matrix_b_gpu
# cp.cuda.Stream.null.synchronize()  # 等待GPU计算完成
end_time_gpu = time.time()
gpu_time = end_time_gpu - start_time_gpu

print(f"CPU 加法时间：{cpu_time:.4f} 秒")
print(f"GPU 加法时间：{gpu_time:.4f} 秒")
