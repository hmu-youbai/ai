import wx

# class Ui_uploadfile:
#     def __init__(self):
#         wx.Frame.__init__(self, None, title="Find File Window")
#
#         # 创建UI元素或定义布局
#         # ...
#
#         # 绑定事件处理函数
#         # ...
#
#         # 显示窗口
#         self.Show()
#     def setupUi(self, uploadfile):
#         uploadfile.SetTitle("log File")
#         uploadfile.SetSize((1576, 699))
#
#     def retranslateUi(self, uploadfile):
#         pass



class Ui_uploadfile(wx.Frame):
    def __init__(self,key_list1):
        wx.Frame.__init__(self, None, title="Find File Window", size=(995, 897))

        self.key_list1 = key_list1
        self.findfirst = wx.ListBox(self, choices=self.key_list1, pos=(100, 50), size=(201, 471))
        self.findfirst_2 = wx.ListBox(self, pos=(380, 50), size=(201, 471))
        self.findfirst_3 = wx.ListBox(self, pos=(660, 50), size=( 201, 471))
        self.txt = wx.TextCtrl(self, pos=(70, 580), size=(841, 251), style=wx.TE_MULTILINE)


        self.setupUi()
        self.retranslateUi()
        self.Show()


    def setupUi(self):
        # 执行其他UI设置，如添加按钮、标签等
        pass

    def retranslateUi(self):
        # 执行UI文本的本地化或翻译
        pass
