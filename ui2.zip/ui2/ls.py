def fatofq(rr,ww):
    i=0
    lolo=0
    i2=0
    with open(rr, "r") as file, open(ww, "w") as file2:
        for line in file:
            line = line.strip()
            i = i + 1
            if i % 2 != 0:
                i2=i2+1
                print("@" + "name"+str(i2), file=file2)
            if i % 2 == 0:
                print(line, file=file2)
                print("+", file=file2)
                print("I" * len(line), file=file2)
                lolo = lolo + len(line)
    lolo2 = (lolo / i) * 2
    file.close()
    file2.close()



import sys
if len(sys.argv) == 2:
        step1 = sys.argv[1]
else:
        print("please input step1_uniq file")
        sys.exit(1)
out_file = str(step1)+"_2"
fatofq(step1,out_file)










def fqtofa(rr,ww):
    i=0
    lolo=0
    i2=0
    with open(rr, "r") as file, open(ww, "w") as file2:
        for line in file:
            line = line.strip()
            i = i + 1
            if i % 4 == 1:
                i2=i2+1
                print(">" + "name"+str(i2), file=file2)
            if i % 4 == 2:
                print(line, file=file2)
                lolo = lolo + len(line)
    lolo2 = (lolo / i) * 2
    file.close()
    file2.close()

import sys
if len(sys.argv) == 2:
        step1 = sys.argv[1]
else:
        print("please input step1_uniq file")
        sys.exit(1)
out_file = str(step1)+"_2"
fqtofa(step1,out_file)















